package com.cognizant.capstone.locationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
