package com.cognizant.capstone.productaggregateservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductAggregateServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
