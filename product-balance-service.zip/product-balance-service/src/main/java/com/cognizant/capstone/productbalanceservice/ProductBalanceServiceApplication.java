package com.cognizant.capstone.productbalanceservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductBalanceServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductBalanceServiceApplication.class, args);
	}

}
