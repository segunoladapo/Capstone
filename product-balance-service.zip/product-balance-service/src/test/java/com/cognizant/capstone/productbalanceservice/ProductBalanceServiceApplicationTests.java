package com.cognizant.capstone.productbalanceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductBalanceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
